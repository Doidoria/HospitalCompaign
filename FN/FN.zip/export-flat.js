const fs = require('fs');
const path = require('path');

// 1. 설정: 원본 'src' 폴더와 파일들이 싹 모일 대상 폴더
const SRC_DIR = path.join(__dirname, 'src'); 
const DIST_DIR = path.join(__dirname, 'attached_flat_files');

console.log(`🔍 원본 폴더 경로: ${SRC_DIR}`);
if (!fs.existsSync(SRC_DIR)) {
    console.error(`❌ 에러: 'src' 폴더를 찾을 수 없습니다. 프로젝트 루트에서 실행 중인지 확인해 주세요.`);
    process.exit(1);
}

// 대상 디렉토리 초기화 (기존에 있으면 지우고 새로 생성)
if (fs.existsSync(DIST_DIR)) {
    fs.rmSync(DIST_DIR, { recursive: true, force: true });
}
fs.mkdirSync(DIST_DIR, { recursive: true });

console.log('🚀 모든 .ts, .tsx 파일을 [폴더명_파일명] 형태로 변환하여 수집 시작...');
let fileCount = 0;

function traverseAndCopyFlat(currentDir) {
    const items = fs.readdirSync(currentDir);

    items.forEach(item => {
        const fullPath = path.join(currentDir, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
            // 제외할 폴더들
            if (item !== 'node_modules' && item !== '.next' && !item.startsWith('.')) {
                traverseAndCopyFlat(fullPath);
            }
        } else {
            // 2. 확장자 체크 (.ts, .tsx)
            const ext = path.extname(item);
            if (ext === '.ts' || ext === '.tsx') {
                
                // src 폴더 기준의 상대 경로를 구합니다. (예: app/about 또는 components)
                const relativeDir = path.relative(SRC_DIR, currentDir);
                
                let newFileName = '';
                if (relativeDir) {
                    // 슬래시(/)나 역슬래시(\)를 언더바(_)로 치환하여 접두어를 만듭니다.
                    // 동적 라우팅의 대괄호 [id] 등은 파일명 안전성을 위해 제거합니다.
                    const prefix = relativeDir.replace(/[\/\\]/g, '_').replace(/[\[\]]/g, '');
                    newFileName = `${prefix}_${item}`;
                } else {
                    // src 바로 밑에 있는 파일인 경우
                    newFileName = `src_${item}`;
                }

                const destPath = path.join(DIST_DIR, newFileName);
                
                // 파일 복사
                fs.copyFileSync(fullPath, destPath);
                console.log(`✅ 변환 및 복사: ${item} ➡️ ${newFileName}`);
                fileCount++;
            }
        }
    });
}

traverseAndCopyFlat(SRC_DIR);
console.log(`\n🎉 작업 완료! 총 ${fileCount}개의 파일이 이름이 변경되어 '${DIST_DIR}' 폴더에 평평하게(Flat) 모였습니다.`);