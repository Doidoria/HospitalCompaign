const fs = require('fs');
const path = require('path');

// [체크] 프로젝트 구조에 맞게 자동으로 소스 폴더를 지정합니다.
let SRC_DIR = path.join(__dirname, 'src', 'app');

if (!fs.existsSync(SRC_DIR)) {
    // 만약 src/app 폴더가 없다면 최상위 app 폴더를 기치로 삼습니다.
    SRC_DIR = path.join(__dirname, 'app');
}

const DIST_DIR = path.join(__dirname, 'attached_pages');

console.log(`🔍 탐색할 대상 폴더 경로: ${SRC_DIR}`);
if (!fs.existsSync(SRC_DIR)) {
    console.error(`❌ 에러: 프로젝트에서 'app' 또는 'src/app' 폴더를 찾을 수 없습니다. 경로를 확인해 주세요.`);
    process.exit(1);
}

// 대상 디렉토리 초기화
if (fs.existsSync(DIST_DIR)) {
    fs.rmSync(DIST_DIR, { recursive: true, force: true });
}
fs.mkdirSync(DIST_DIR, { recursive: true });

console.log('🚀 page.tsx 파일 수집 시작...');
let copyCount = 0;

function traverseAndCopy(currentDir) {
    const items = fs.readdirSync(currentDir);

    items.forEach(item => {
        const fullPath = path.join(currentDir, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
            // 라우팅과 관계없는 노드 모듈이나 빌드 폴더, 숨김 폴더는 패스
            if (item !== 'node_modules' && item !== '.next' && !item.startsWith('.')) {
                traverseAndCopy(fullPath);
            }
        } else if (item === 'page.tsx' || item === 'page.jsx') { // jsx 확장자도 고려
            const relativePath = path.relative(SRC_DIR, currentDir);
            
            // 이름 조합
            const prefix = relativePath ? relativePath.replace(/[\/\\]/g, '_') + '_' : 'root_';
            // dynamic route (예: [id])의 대괄호가 파일명에 들어가면 문제가 생길 수 있으므로 안전하게 변경
            const safePrefix = prefix.replace(/[\[\]]/g, '');
            const newFileName = `${safePrefix}${item}`;

            const destPath = path.join(DIST_DIR, newFileName);
            
            fs.copyFileSync(fullPath, destPath);
            console.log(`✅ 복사 완료: ${relativePath || 'root'} -> ${newFileName}`);
            copyCount++;
        }
    });
}

traverseAndCopy(SRC_DIR);
console.log(`\n🎉 작업 완료! 총 ${copyCount}개의 파일이 '${DIST_DIR}' 폴더로 복사되었습니다.`);